// proxy-handler.js

// Replace the old stub with calls into background.js
if (!window.proxyHandler) {
  window.proxyHandler = {
    /**
     * Tells background page to apply this proxy
     */
    applyProxy: async (proxy) => {
      console.log("Requesting applyProxy:", proxy)
      return new Promise((resolve, reject) => {
        chrome.runtime.sendMessage({ action: "applyProxy", proxy }, (response) => {
          if (chrome.runtime.lastError) return reject(chrome.runtime.lastError)
          if (response && response.error) return reject(new Error(response.error))
          resolve(response && response.success)
        })
      })
    },

    /**
     * Tells background page to clear proxy
     */
    clearProxy: async () => {
      console.log("Requesting clearProxy")
      return new Promise((resolve, reject) => {
        chrome.runtime.sendMessage({ action: "clearProxy" }, (response) => {
          if (chrome.runtime.lastError) return reject(chrome.runtime.lastError)
          if (response && response.error) return reject(new Error(response.error))
          resolve(response && response.success)
        })
      })
    },

    /**
     * Parse proxy file content
     */
    parseProxyFile: (content) => {
      if (!content) return []

      // Split by newlines and filter out empty lines
      const lines = content.split("\n").filter((line) => line.trim() !== "")

      // Parse each line into a proxy object
      return lines
        .map((line) => {
          const parts = line.trim().split(":")
          if (parts.length < 4) {
            // If format is not complete, try to parse what we have
            return {
              host: parts[0] || "",
              port: parts[1] || "",
              username: parts[2] || "",
              password: parts[3] || "",
              blocked: false,
              lastUsed: null,
            }
          }

          return {
            host: parts[0],
            port: parts[1],
            username: parts[2],
            password: parts[3],
            blocked: false,
            lastUsed: null,
          }
        })
        .filter((proxy) => proxy.host && proxy.port) // Filter out invalid proxies
    },

    /**
     * Get the next available proxy
     */
    getNextProxy: (proxies, blockedProxies = []) => {
      if (!proxies || proxies.length === 0) return null

      // Filter out blocked proxies
      const availableProxies = proxies.filter(
        (proxy) =>
          !proxy.blocked &&
          !blockedProxies.some((blocked) => blocked.host === proxy.host && blocked.port === proxy.port),
      )

      if (availableProxies.length === 0) return null

      // Sort by last used time (null first, then oldest first)
      availableProxies.sort((a, b) => {
        if (a.lastUsed === null) return -1
        if (b.lastUsed === null) return 1
        return a.lastUsed - b.lastUsed
      })

      // Return the first available proxy
      const proxy = availableProxies[0]
      proxy.lastUsed = Date.now()
      return proxy
    },

    /**
     * Mark a proxy as blocked
     */
    markProxyAsBlocked: (proxies, proxyToBlock) => {
      if (!proxies || proxies.length === 0 || !proxyToBlock) return proxies

      return proxies.map((proxy) => {
        if (proxy.host === proxyToBlock.host && proxy.port === proxy.port) {
          return { ...proxy, blocked: true }
        }
        return proxy
      })
    },

    /**
     * Test a proxy
     */
    testProxy: async (proxy) => {
      console.log("Requesting testProxy:", proxy)
      return new Promise((resolve, reject) => {
        chrome.runtime.sendMessage({ type: "test_proxy", proxy }, (response) => {
          if (chrome.runtime.lastError) return reject(chrome.runtime.lastError)
          resolve(response)
        })
      })
    },
  }
}

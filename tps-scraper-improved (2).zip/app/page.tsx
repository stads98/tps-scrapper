"use client"

import  from "../background"

export default function SyntheticV0PageForDeployment() {
  return < />
}